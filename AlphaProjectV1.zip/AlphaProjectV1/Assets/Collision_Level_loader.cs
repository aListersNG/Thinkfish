﻿using UnityEngine;
using System.Collections;

public class Collision_Level_loader : MonoBehaviour
{

    void Start()
    {

    }

    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D col)
    {
       if(col.gameObject.tag == "Player")
        {
            Application.LoadLevel("Alpha_Player_Movement");
        }
    }
	
}

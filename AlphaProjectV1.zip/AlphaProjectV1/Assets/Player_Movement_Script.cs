﻿using UnityEngine;
using System.Collections;

public class Player_Movement_Script : MonoBehaviour
{
    //Player Movement Variables

    private float movex;
    public float movespeed = 1;

    private Rigidbody2D player;

	// Use this for initialization
	void Start ()
    {
        player = gameObject.GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void FixedUpdate ()
    {

        float h = Input.GetAxis("Horizontal");

        player.AddForce(Vector2.right * movespeed * h);

    }
}

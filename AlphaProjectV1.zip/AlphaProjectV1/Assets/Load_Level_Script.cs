﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Load_Level_Script : MonoBehaviour
{

    void Start()
    {

    }


    void Update()
    {

    }

	public void ChangeScene(string Alpha_Player_Movement)
    {
        Application.LoadLevel("Alpha_Player_Movement");
	}
}

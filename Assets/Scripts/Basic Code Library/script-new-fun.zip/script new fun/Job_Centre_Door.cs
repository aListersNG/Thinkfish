﻿using UnityEngine;
using System.Collections;

public class Job_Centre_Door : MonoBehaviour
{

    void OnTriggerStay2D(Collider2D col)
    {
        if (col.gameObject.tag == "Player" && Input.GetKeyDown(KeyCode.E)) // Developed by Andrew McGonigal
        {
            
            Application.LoadLevel("Alpha_Job_Centre_inside");
            
        }

    }


}
